---
name: "\U0001F46E‍♂️Security issue"
about: Please report security issues *only* via https://www.hackerone.com
title: ''
labels: ''
assignees: ''

---

For security reasons, please report all security issues via https://hackerone.com/automattic/.  Also, if the issue is valid, a bug bounty will be paid out to you. 

Please disclose responsibly and not via GitHub (which allows for exploiting issues in the wild before the patch is released).
