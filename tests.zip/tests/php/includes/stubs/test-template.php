<strong>Rich Test Email: <?php echo esc_html( $args['job']->post_title ); ?></strong>
